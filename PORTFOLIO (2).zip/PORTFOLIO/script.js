// Smooth Scrolling for Navigation Links
document.querySelectorAll('nav a').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const targetId = this.getAttribute('href').substring(1);
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// Scroll Animation for Sections
const sections = document.querySelectorAll('.animate-on-scroll');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animation = 'fadeInUp 0.8s ease-out forwards';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  sections.forEach(section => observer.observe(section));
} else {
  // Fallback for older browsers: show sections without animation
  sections.forEach(section => {
    section.style.opacity = '1';
  });
}

// Contact Form Validation
const contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');

    if (!nameInput || !emailInput || !messageInput) {
      console.error('Form elements not found');
      alert('Error: Form elements are missing. Please check the HTML.');
      return;
    }

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const message = messageInput.value.trim();

    if (name && email && message) {
      console.log('Form Submitted:', { name, email, message });
      alert('Message sent! (This is a demo, data is logged to console. Use Formspree for production.)');
      this.reset();
    } else {
      alert('Please fill out all fields.');
    }
  });
} else {
  console.error('Contact form not found');
}